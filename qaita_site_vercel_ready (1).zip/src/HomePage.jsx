import React from "react";

export default function HomePage() {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif", textAlign: "center" }}>
      <h1>Qaita.kz</h1>
      <p>Білім – болашақтың кілті. Бұл платформада қазақтың тарихы мен мәдениетіне арналған тесттер мен сабақтар бар.</p>
    </div>
  );
}