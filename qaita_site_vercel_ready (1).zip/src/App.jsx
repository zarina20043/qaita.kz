import React from "react";
import HomePage from "./HomePage";

export default function App() {
  return <HomePage />;
}